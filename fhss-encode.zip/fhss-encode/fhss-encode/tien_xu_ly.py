import numpy as np
from scipy.io.wavfile import read

def read_message_from_file(file_path):
    # Doc noi dung tu file message.txt
    with open(file_path, "r", encoding="utf-8") as file:
        return file.read().strip()

# Doc file am thanh
Fs, audio = read("sample_29s.wav")
audio = audio.astype(float)

# Kiem tra neu file goc la stereo, chuyen ve mono de giau tin
is_stereo = False
if audio.ndim > 1:
    is_stereo = True
    audio_mono = np.mean(audio, axis=1)  # Chuyen thanh mono
else:
    audio_mono = audio.copy()  # Neu la mono, giu nguyen

# Chuyen message thanh bit nhi phan
# Them chuoi dong bo vao dau message
message = read_message_from_file("message.txt")
sync_sequence = "10101010" * 3  # Lap lai 3 lan => de nhan dien
message = sync_sequence + message
binary_message = np.array([int(b) for char in message for b in format(ord(char), '08b')])

# Ghi file sau tien xu ly
np.savetxt("audio_mono.txt", audio_mono)
np.savetxt("binary_message.txt", binary_message, fmt="%d")

with open("Fs.txt", "w") as f:
    f.write(str(Fs))
with open("is_stereo.txt", "w") as f:
    f.write(str(int(is_stereo)))
print("Tien xu ly du lieu thanh cong!")
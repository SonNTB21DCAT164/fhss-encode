import numpy as np
from scipy.io.wavfile import write

# Doc du lieu tien xu ly
audio_mono = np.loadtxt("audio_mono.txt")
binary_message = np.loadtxt("binary_message.txt", dtype=int)

with open("Fs.txt") as f:
    Fs = int(f.read().strip())
with open("is_stereo.txt") as f:
    is_stereo = bool(int(f.read().strip()))

# Tao chuoi nhay tan PN
num_frequencies = 6 # So luong tan so su dung de nhay tan
# Tao chuoi PN ngau nhien, moi bit truyen bang 1 tan so
PN_seq = np.random.randint(0, num_frequencies, len(binary_message))
# Bo to hop tan
frequencies = np.linspace(1000, 5000, num_frequencies)  # Tần số 1-5 kHz

# Dieu che FSK
T_bit = 0.01    # Thoi gian cho moi bit
Ts = 1 / Fs     # Chu ky lay mau
t = np.arange(0, T_bit, Ts) # Mang thoi gian cho tung bit

# Tao tin hieu FHSS bang cach dieu che theo tung bit cua chuoi nhi phan
fhss_signal = np.concatenate([
    np.sin(2 * np.pi * frequencies[PN_seq[i]] * t) * (2 * binary_message[i] - 1)
    for i in range(len(binary_message))
])

# Tron tin hieu FHSS vao am thanh goc
# Chen tin hieu FHSS vao cuoi neu do dai chua du
fhss_signal = np.pad(fhss_signal, (0, max(0, len(audio_mono) - len(fhss_signal))), mode='constant')[
              :len(audio_mono)]
# Giau tin bang cach cong tin hieu FHSS vao audio
# embedded_audio = audio_mono + 0.01 * fhss_signal
# Dieu chinh muc do de nghe ro hon
scale_factor = 0.01  # co the tang len
fhss_signal = fhss_signal / np.max(np.abs(fhss_signal)) * np.max(np.abs(audio_mono))
embedded_audio = audio_mono + scale_factor * fhss_signal

# Neu file goc la stereo, nhan doi kenh de giu dinh dang stereo
if is_stereo:
    embedded_audio = np.column_stack((embedded_audio, embedded_audio))

# File audio sau khi da giau tin
write("output.wav", Fs, embedded_audio.astype(np.int16))
print("Giau tin thanh cong!")